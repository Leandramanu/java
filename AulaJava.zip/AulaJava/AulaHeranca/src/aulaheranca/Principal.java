/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aulaheranca;

/**
 *
 * @author IFTM
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Funcionario maria = new Funcionario();
        maria.setNome("Maria");
        maria.setSobrenome("Silva");
        maria.setSalario(620.00);
        System.out.println("Funcionario: " + maria.getNome() + " " + maria.getSobrenome() + "\n" + "Salario: R$" + maria.getSalario());
        
        FuncionarioComissionado marcelo = new FuncionarioComissionado();
        marcelo.setNome("Marcelo");
        marcelo.setSobrenome("Bastos");
        marcelo.setSalario(700.00);
        marcelo.setComissao(20.00);
        marcelo.setVenda(10);
        
        System.out.println("*********************************************");
        
        String mostrar = "Funcionario Comissionado: " + marcelo.getNome() + " " + marcelo.getSobrenome() + " \n " + "Salario Fixo: " + marcelo.getSalario();
        
        System.out.println(mostrar + "\n" + "Comissao: R$ " + marcelo.getComissao() + "\nQntde Vendas: " + marcelo.getVenda());
        
        System.out.println("*******************************************************************");
        System.out.println("mais 3 vendas");
        marcelo.acrescentarVenda(3);
        System.out.println(mostrar + "\n" + "Comissao: R$ " + marcelo.getComissao() + "\nQntde vendas: " + marcelo.getVenda() + " - Salario Final: " + marcelo.calcularComissao());
        
        System.out.println("*******************************************************************");
        System.out.println("zerar vendas");
        marcelo.zerarVendas();
        System.out.println(mostrar + "\n" + "Comissao: R$ " + marcelo.getComissao() + "\nQntde vendas: " + marcelo.getVenda() + " - Salario Final: " + marcelo.calcularComissao());
        
        
        
        
        
        // TODO code application logic here
    }
    
}
