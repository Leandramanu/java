package aulajava;

import javax.swing.JOptionPane;

/**
 *
 * @author Leandra
 */
public class Principal 
{

    public static void main(String[] args) 
    {
//        System.out.println("Ola Mundo!");
//        System.out.println("POO 1");
        
        JOptionPane.showMessageDialog(null, "3 periodo ADS");
    }
    
}
