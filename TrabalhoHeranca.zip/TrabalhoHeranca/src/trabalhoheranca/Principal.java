/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trabalhoheranca;

/**
 *
 * @author IFTM
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        
        Pessoa mario = new Pessoa();
        mario.setCodigo(1);
        mario.setNome("Mario");
        mario.setDataCadastro("25/03/25");
        
        System.out.println("------------ PESSOA ------------");
        System.out.println(" Pessoa: " + mario.getNome() + "\n Codigo: " + mario.getCodigo() + "\n Data Cadastro: " + mario.getDataCadastro());
        System.out.println(" \n ");
        
        Pessoa ana = new Pessoa();
        ana.setCodigo(2);
        ana.setNome("Ana");
        ana.setDataCadastro("26/03/25");
        
        System.out.println(" Pessoa: " + ana.getNome() + "\n Codigo: " + ana.getCodigo()   
                            + "\n Data Cadastro: " + ana.getDataCadastro());
        System.out.println(" \n ");
        
        System.out.println("------------ CLIENTE ------------");
        Cliente joao = new Cliente();
        joao.setCodigo(3);
        joao.setNome("Joao");
        joao.setDataCadastro("26/03/25");
        joao.setEmail("joao@gmail.com");
        joao.setEndereco("Rua Alamedas");
        joao.setTelefone("34.1234-5678");
        
        System.out.println(" Cliente: " + joao.getNome() + "\n Codigo: " + joao.getCodigo() 
                            + "\n Data Cadastro: " + joao.getDataCadastro() + "\n Email: " 
                            + joao.getEmail() + "\n Endereco: " + joao.getEndereco()   
                            + "\n Telefone: " + joao.getTelefone());
        System.out.println(" \n ");
        
        Cliente robson = new Cliente();
        robson.setCodigo(4);
        robson.setNome("Robson");
        robson.setDataCadastro("05/03/25");
        robson.setEmail("robson@gmail.com");
        robson.setEndereco("Rua Jararacas");
        robson.setTelefone("34.9999-5222");
        
        System.out.println(" Cliente: " + robson.getNome() + "\n Codigo: " + robson.getCodigo()
                            + "\n Data Cadastro: " + robson.getDataCadastro() + "\n Email: " 
                            + robson.getEmail() + "\n Endereco: " + robson.getEndereco() 
                            + "\n Telefone: " + robson.getTelefone());
        System.out.println(" \n ");
        
        System.out.println("------------ USUARIO ------------");
        Usuario maria = new Usuario();
        maria.setCodigo(5);
        maria.setNome("Maria");
        maria.setDataCadastro("09/03/25");
        maria.setLogin("Maria1");
        maria.setSenha("Maria123");
        
        System.out.println(" Usuario: " + maria.getNome() + "\n Codigo: " + maria.getCodigo()
                            + "\n Data Cadastro: " + maria.getDataCadastro() + "\n Login: " 
                            + maria.getLogin() + "\n Senha: " + maria.getSenha());
        System.out.println(" \n ");
        
        Usuario paula = new Usuario();
        paula.setCodigo(6);
        paula.setNome("Paula");
        paula.setDataCadastro("09/03/25");
        paula.setLogin("Paula2");
        paula.setSenha("Paulaaluap");
        
        System.out.println(" Usuario: " + paula.getNome() + "\n Codigo: " + paula.getCodigo()
                            + "\n Data Cadastro: " + paula.getDataCadastro() + "\n Login: " 
                            + paula.getLogin() + "\n Senha: " + paula.getSenha());
        System.out.println(" \n ");
        
        
    }
    
}
