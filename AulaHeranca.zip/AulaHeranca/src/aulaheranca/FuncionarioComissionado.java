/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aulaheranca;

/**
 *
 * @author IFTM
 */
public class FuncionarioComissionado extends Funcionario
{
    private double comissao;
    private int venda;

    public double getComissao() {
        return comissao;
    }

    public void setComissao(double comissao) {
        this.comissao = comissao;
    }

    public int getVenda() {
        return venda;
    }

    public void setVenda(int venda) {
        this.venda = venda;
    }
    
    public void acrescentarVenda (int venda)
    {
        this.venda += venda;
    }
    
    public void zerarVendas()
    {
            this.venda = 0;
    }
    
    public double calcularComissao ()
    {
        double valor = super.getSalario() + (this.comissao + this.venda);
        return valor;
    
    }
    
    
    
}
